const express=require('express')

const app=express();

const Port=4800;

app.use(express.json())

app.get('/',(req,resp)=>{
    resp.send({msg:`i am homepage`})
})
app.get('/about',(req,resp)=>{
    resp.send({msg:`i am aboutpage`})
})
app.get('/contact',(req,resp)=>{
    resp.send({email:`support@pwskills.com`})
})

app.listen(Port,()=>{
    console.log(`Server Running at Port : ${Port}`);
})