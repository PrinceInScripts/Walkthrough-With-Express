const WomenData=[{
    "id":1,
    "name":"Women's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":2,
    "name":"Women's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":3,
    "name":"Women's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":4,
    "name":"Women's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":5,
    "name":"Women's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":6,
    "name":"Women's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":7,
    "name":"Women's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":8,
    "name":"Women's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":9,
    "name":"Women's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":10,
    "name":"Women's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
}

]

module.exports=WomenData;