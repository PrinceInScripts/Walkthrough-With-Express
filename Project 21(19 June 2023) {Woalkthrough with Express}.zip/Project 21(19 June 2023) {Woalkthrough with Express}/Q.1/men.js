const MenData=[{
    "id":1,
    "name":"Men's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":2,
    "name":"Men's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":3,
    "name":"Men's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":4,
    "name":"Men's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":5,
    "name":"Men's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":6,
    "name":"Men's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":7,
    "name":"Men's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":8,
    "name":"Men's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":9,
    "name":"Men's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
},
{
    "id":10,
    "name":"Men's T-shirt",
    "brand":"ABC",
    "price":19.90,
    "color":"Blue",
    "size":"M",
    "category":"Clothing"
}

]

module.exports=MenData;