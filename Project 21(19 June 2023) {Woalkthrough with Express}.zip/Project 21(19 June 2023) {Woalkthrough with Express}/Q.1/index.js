const http=require('http');

const MenData=require("./men")
const WomenData=require("./women")

const Port=5000;
const hostname="localhost";

const server=http.createServer((req,resp)=>{
         resp.statusCode=200;
         resp.setHeader("Content-Type","Application/Json");
        

         if(req.url === "/"){
            resp.statusCode=200;
            resp.setHeader("Content-Type","text/plain");
            resp.write("Welcome to Men & Women Dummy Data")
         }
         else if(req.url === "/men"){
            resp.statusCode=200;
            resp.setHeader("Content-Type","Application/Json");
            resp.write(JSON.stringify(MenData))
         }
         else if(req.url === "/women"){
            resp.statusCode=200;
            resp.setHeader("Content-Type","Application/Json");
            resp.write(JSON.stringify(WomenData))
         }
         else
         {
            resp.statusCode=500;
            resp.setHeader("Content-Type","text/plain");
            resp.write("page not found")
         }

         resp.end()
         
})

server.listen(Port,()=>{
    console.log(`Server Running at ${hostname}:${Port}`);
})