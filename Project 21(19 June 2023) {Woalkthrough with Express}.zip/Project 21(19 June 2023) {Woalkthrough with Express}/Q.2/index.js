const express=require('express');

const app=express();

app.use(express.json())

let counter=0;

const Port=4600;
const hostname="localhost";

app.get('/',(req,resp)=>{
    resp.send({counter})
})

app.post('/increment',(req,resp)=>{
    if(counter>0)
       counter++
       resp.send({counter})
})

app.post('/decrement',(req,resp)=>{
    if(counter>0)
    counter--;
    resp.send({counter})
})

app.listen(Port,()=>{
    console.log(`Server Running at ${hostname}:${Port}`);
})