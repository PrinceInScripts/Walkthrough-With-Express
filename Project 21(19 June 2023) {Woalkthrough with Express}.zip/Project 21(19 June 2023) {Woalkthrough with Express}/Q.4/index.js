const express=require("express")

const app=express();

Port=5000;

app.use(express.json())

app.get("/random",(req,resp)=>{
    let randomNum=Math.floor(Math.random()*100)
    resp.send({random:randomNum});
})

app.listen(Port,()=>{
    console.log(`Server Running at Port : ${Port}`);
})


